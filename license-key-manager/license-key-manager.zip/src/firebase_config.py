FIREBASE_API_KEY = "AIzaSyCEs8MKF0RmAc9d4ykvJHVGAJ5iajWO2Uo"
FIREBASE_PROJECT_ID = "license-85285"
FIREBASE_DATABASE_URL = f"https://firestore.googleapis.com/v1/projects/{FIREBASE_PROJECT_ID}/databases/(default)/documents"